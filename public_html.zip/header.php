<header>
    <a href="https://gsfmusic.gr" title="GSF Music" class="logo" class="iconHover">
        <img src="icons/GSF_logo_white.png" alt="Αρχική">
    </a>
    <a target="_blank" href="https://www.gsfrecords.com" title="E-shop" class="iconHover">
        <img src="icons/nav-eshop.png" alt="eshop">
    </a>
    <a target="_blank" href="https://www.facebook.com/gsfmusicofficial" title="Facebook" class="iconHover">
        <img src="icons/facebook.png" alt="facebook">
    </a>
    <a target="_blank" href="https://www.instagram.com/gsfmusicofficial/" title="Instagram" class="iconHover">
        <img src="icons/instagram.png" alt="youtube">
    </a>
    <a target="_blank" href="https://www.youtube.com/channel/UCUTJlf84CFiq-eUU0M6Vf3A?sub_confirmation=1%C2%A8" title="YouTube" class="iconHover">
        <img src="icons/youtube-icon.png" alt="youtube">
    </a>
    <a href="" title="Email" class="emailMenuIcon">
        <img src="icons/email.png" alt="email">
        <span class="emailTag">csamouridis@gsfmusic.gr</span>
    </a>
</header>