<?php
$conn = mysqli_connect( 'localhost', 'u174548577_charalampos', '386900072422211Le', 'u174548577_url_shortener' );